Most of the parts of the codes were created orginally by Salehi et al. (2021), and the link for the original codes can be found in the github: https://github.com/rohban-lab/Knowledge_Distillation_AD.

We have revised some parts of Salehi et al. (2021) codes to help solve the questions raised in this paper, including the GTC-KD which proposed by us.

Given the file size is quite large, we only included most of parts of codes here.
You can download other codes from: https://download.pytorch.org/models/vgg16-397923af.pth, and https://adamz.digital/link/zrDcAQMF7jy6QqZB?clash=1

Please feel free to let us know if you have any questions.


Citations
Salehi, M., Sadjadi, N., Baselizadeh, S., Rohban, M. H., & Rabiee, H. R. (2021). Multiresolution knowledge distillation for anomaly detection. In In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition recognition (pp. 14902-14912). https://doi.org/10.1109/cvpr46437.2021.01466.
Chen, Y. W., Zhu, G. P. (2023) Using teacher-student neural networks based on knowledge distillation to detect anomalous samples in the otolith images. Zoology, in revision.
