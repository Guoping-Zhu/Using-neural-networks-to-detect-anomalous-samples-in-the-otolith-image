#!/bin/bash
#SBATCH -J AD_mvtec
#SBATCH -p defq
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
#SBATCH -t 6-23:59:59
#SBATCH --gres=gpu:1

tmpFolder="/ssd/$SLURM_JOB_USER/$SLURM_JOB_ID"
#cp -rf /home/50505008/xingp_ng/CutMix-PyTorch $tmpFolder

cd /mnt/10202002/Knowledge_Distillation_AD
python -u train_last.py